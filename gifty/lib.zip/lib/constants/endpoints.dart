const api_endpoint_user_login = 'https://gifty-back.vercel.app/api/user_login';
const api_endpoint = 'http://10.0.2.2:5000';
const api_endpoint_user_signup = 'https://gifty-back.vercel.app/api/user_signup';
