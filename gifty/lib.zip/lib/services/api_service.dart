import 'dart:convert';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import '../databases/DBGift.dart';

class ApiService {
  final String baseUrl;

  ApiService(this.baseUrl);

  Future<List<dynamic>> fetchUsers() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/api/get_users'));

      if (response.statusCode == 200) {
        final decodedData = json.decode(response.body);
        print("heeeeere");
        print(decodedData);
        List<dynamic> userList = decodedData['users'];
        return userList;
      } else {
        throw Exception('Failed to load data from Supabase');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  Future<void> inserUser(Map<String, dynamic> userData) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/insert_user'),
        body: json.encode(userData),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode != 200) {
        throw Exception('Failed to insert user into Supabase');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  Future<List<dynamic>> fetchData() async {
    final response = await http.get(Uri.parse('$baseUrl/api/data'));

    if (response.statusCode == 200) {
      // If the server returns a 200 OK response, parse the data
      return json.decode(response.body);
    } else {
      // If the server did not return a 200 OK response,
      // throw an exception.
      throw Exception('Failed to load data');
    }
  }

  Future<Map<String, dynamic>> sendData(Map<String, dynamic> data) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/data'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(data),
    );

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to send data');
    }
  }

  Future<List<dynamic>> fetchGifts() async {
    final response = await http.get(Uri.parse('$baseUrl/gifts.get'));

    if (response.statusCode == 200) {
      return json.decode(response.body)['gifts'];
    } else {
      throw Exception('Failed to load gifts');
    }
  }

  // Future<void> addGift(Map<String, dynamic> newGift) async {
  //   try {
  //     final response = await http.post(
  //       Uri.parse('$baseUrl/gifts.add'),
  //       body: {'new_gift': json.encode(newGift)},
  //     );

  //     if (response.statusCode != 200) {
  //       throw Exception(
  //           'Failed to add gift,  statusCode:${response.statusCode}');
  //     }
  //   } catch (e) {
  //     throw Exception('Error: $e');
  //   }
  // }

  Future<void> addGift(Map<String, dynamic> newGift) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/gifts.add'),
        body: json.encode(newGift),
        headers: {'Content-Type': 'application/json'},
      );
      
      String responseBody = response.body;
      Map<String, dynamic> parsedJson = jsonDecode(responseBody);
       
      int gift_id = parsedJson['id'];

      var colors = [];
      for ( var color in  newGift['colors']){
           colors.add({
            'product_id': gift_id,
            'color': color
            });
      }

      final responseColor = await http.post(
        Uri.parse('$baseUrl/colors.add'),
        body: json.encode(colors),
        headers: {'Content-Type': 'application/json'},
      );


      for ( var img in  newGift['images']){
           img['product_id'] = gift_id;
      }
      final responsePaths = await http.post(
        Uri.parse('$baseUrl/images.add'),
        body: json.encode(newGift['images']),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.statusCode == 308) {
        // If the status code is 308, follow the redirection
        final redirectUrl = response.headers['location'];
        if (redirectUrl != null) {
          await http.post(
            Uri.parse(redirectUrl),
            body: {'new_gift': json.encode(newGift)},
          );
        } else {
          throw Exception('Redirect URL not provided in the response headers.');
        }
      } else if (response.statusCode != 200) {
        throw Exception(
            'Failed to add gift,  statusCode: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  Future<Map<String, dynamic>> getGiftById(int giftId) async {
    final response = await http.get(Uri.parse('$baseUrl/api/gifts/$giftId'));

    if (response.statusCode == 200) {
      return json.decode(response.body)['gift'];
    } else {
      throw Exception('Failed to get gift by ID');
    }
  }

  Future<void> updateGift(int giftId, Map<String, dynamic> updatedGift) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/api/gifts/$giftId'),
        body: json.encode(updatedGift),
      );

      if (response.statusCode != 200) {
        throw Exception('Failed to update gift');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  Future<void> deleteGift(int giftId) async {
    try {
      final response =
          await http.delete(Uri.parse('$baseUrl/api/gifts/$giftId'));

      if (response.statusCode != 200) {
        throw Exception('Failed to delete gift');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }

  Future<bool> service_sync_gifts() async {
    print("Running Cron Service to get gifts");
    List<dynamic>? remote_data = await fetchGifts();

    if (remote_data != null) {
      await DBGift.syncGifts(remote_data as List<dynamic>);
      return true;
    }
    return false;
  }

  Future<String> uploadImage(imageBytes) async {
    try {
      final response = await http.post(Uri.parse('$baseUrl/upload'), body: {'image': imageBytes});
       String responseBody = response.body;
       Map<String, dynamic> parsedJson = jsonDecode(responseBody);
       
       String image_url = parsedJson['image_url'];

      if (response.statusCode == 200) {
        final decodedData = json.decode(response.body);
        return image_url ;
      } else {
        throw Exception('Failed to load data from Supabase');
      }
    } catch (e) {
      throw Exception('Error: $e');
    }
  }
}

